<!-- Estilizar imagem de fundo e textos
somente formatar -->
<html>
<head>
</head>
    <title>Área do triângulo</title>
	<style>
	    body {
			background-image: url("matback.jpg");
			background-repeat: no-repeat;
			background-size: cover;
		}
	</style>
<body>
<fieldset style="margin: 430px; border-color: black; border-radius: 4px ; width: 200px; border: outset; border-width: 40px; border-style: ouset; background-color: lightgray">
	<div class="quadro">
		<h1>Área</h1>
		<h3>
		<?php
		$altura = $_GET["a"];
		$base = $_GET["b"];
		$resultado=($altura * $base)/2;
		echo "Área do triângulo: $resultado";
		?>
		</h3>
	</div>
<footer>
  <p> @ registro by Maria Clara.</p>
</footer>
</body>
</html>