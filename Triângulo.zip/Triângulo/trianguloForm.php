<!-- Estilizar plano de fundo e textos -->
<html>
<head>
	<style>
		body {
			background-image: url("matback.jpg");
			background-repeat: no-repeat;
			background-size: cover;
		}
        input {
            font-family: Arial, sans-serif;
            font-size: 12px;
            background-color: #ffffff;
            border: 2px solid #ddd;
        }
        body{
            text-align:center;
            background-color:#ffcc8e;
        }
        
	</style>
</head>
<body>
<fieldset style="margin: 400px; border-color: black; border-radius: 4px ; width: 200px; border: groove; border-width: 45px; border-style: outset; background-color: lightgray">
<form action="triangulo.php" method="get">
 <p>Altura:   <input type="text" name="a" /></p>
 <p>Largura:  <input type="text" name="b" /></p>
 <div class="container mt-5">
 <div class="row justify-content-center">
    <form>
      <button type="submit"  class="btn btn-warning btn-lg btn-block">Enviar</button>
    </form>
      </div>
</form>
</body>



