<?php
$altura = filter_input(INPUT_POST, "a");
$base = filter_input(INPUT_POST, "b");
$resultado=($altura * $base)/2;
?>
<html>
    <head>
        <style>
            p{
            font-family: american_captain;
            font-size: 25px;
            font-weight: bold;
            color: #ffffff;
      	    }
            body {background:url(fundoTri.png);
			background-repeat: no-repeat;
			background-size: 100%;}

            form {
            font-family: Arial, sans-serif;
            font-size: 20px;
            line-height: 1.5;
            margin: 0 auto;
            text-align: center;
            max-width: 400px;
            }
        
            input[type=text], input[type=email], textarea {
            display: block;
            width: 100%;
            padding: 10px;
            border: 1px solid #333;
            border-radius: 5px;
            box-sizing: border-box;
            margin-bottom: 10px;
            }
        
            input[type=submit] {
            background-color: #ffffff;
            color: #222;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            } 
        </style>
    </head>
    <body>
    <div class=classeE>
    <form method="post"><br>
    <p>INFORMAÇÕES DO TRIÂNGULO<br>
    Altura: <input type="text" name="a" /><br>
    Largura: <input type="text" name="b" /></p><br>
    <h1><input type="submit" value="ENVIAR" /></h1>
    </form>
    <center>
    	<?php
	echo "<br><p> A área do triangulo é: <br>$resultado";
	?>
    </center>
        </div>


    </body>
</html>