<?php
$alt = filter_input(INPUT_POST, "a");
$larg = filter_input(INPUT_POST, "l");
$resultado=($alt + $larg) * 2;
?>

<html>
    <head>
        <style>
            p{
            font-family: american_captain;
            font-size: 25px;
            font-weight: bold;
            color: #ffffff;
      	    }
            body {background:url(fundoRet.png);
			background-repeat: no-repeat;
			background-size: 100%;}

            form {
            font-family: Georgia;
            font-size: 10px;
            margin: 0 auto;
            max-width: 400px;
            }
        
            input[type=text], input[type=email], textarea {
            display: block;
            width: 100%;
            padding: 10px;
            border: 5px solid #000;
            border-radius: 5px;
            box-sizing: border-box;
            margin-bottom: 10px;
            }
        
            input[type=submit] {
            background-color: #ffffff;
            color: #222;
            border: none;
            border-radius: 2px;
            padding: 10px 20px;
            cursor: pointer;
            } 
        </style>
    <head>
    <body><br><br><br><center>
    <form method="post">
    <p>INFORMAÇÕES DO RETÂNGULO</p>
    <p>Altura<input type="text" name="a" /></p>
    <p>Largura<input type="text" name="l" /></p>
    <p><input type="submit" value="ENVIAR" /></p>
    </form>
    <?php
    echo "<br><p> O perímetro do retângulo é: <br>$resultado";
    ?>
    </center>
    </body>
</html>