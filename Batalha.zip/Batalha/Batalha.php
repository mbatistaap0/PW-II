﻿<html>
<head>
   <meta charset= "UTf-8">
   </head>
   <body background = "fundo.jpg">
</html>
<?php
   if(isset($_POST["Time1"])) $time1 = $_POST["Time1"];
   else $time1 = "Indefinido";
   
   if(isset($_POST["time2"])) $time2 = $_POST["time2"];
   else $time2 = "Indefinido";

   
   if($time1 == "Mikasa"){
      echo "<h1><font color = White><center>Mikasa</center></font>;
	        <center><img src=mikasa.jpg height=300 width=320></center>";
	  $p1 = 10200;
   }
     else if($time1 == "ereh"){
        echo "<h1><font color = White><center>Eren</center>
	          <center><img src=ereh.png height=300 width=340></center></font>";
	    $p1 = 12000;
			
     }
	 else if($time1 == "livai"){
        echo "<h1><font color = White><center>Levi</center>
	          <center><img src=levizinho.png height=300 width=310></center></font>";
	    $p1 = 11200;
			
     }
     else if($time1 == "Armin"){
        echo "<h1><font color = White><center>Armin</center>
	          <center><img src=armin.png height=300 width=290></center></font>";
	    $p1 = 7000;	
     }
   
   echo "<br><center><font size=13 color = Red> VS </font></center><br>";
   
   if($time2 == "reiner"){
      echo "<h1><font color = White><center>Reiner</center></font>
	        <center> <img src=Reiner.jpg height=300 width=320></center>";
	  $p2 = 4000;
   }
   else if($time2 == "bert"){
      echo "<h1><font color = White><center>Berthold</center></font>
	        <center><img src=bertinho.jpg height=300 width=310></center>";
	  $p2=5000;
   }
   else if($time2 == "Annie"){
	echo "<h1><font color = White><center>Annie</center></font>
		  <center><img src=annie.png height=300 width=320></center>";
	$p2=5000;
 }
   else if($time2 == "porco"){
      echo "<h1><font color = White><center>Porco</center></font>
	        <center><img src=porco.jpg height=300 width=320></center>";
      $p2=4500;
   }
   echo"<br><br><br>";
       
   if($p1 > $p2){
      if($time1 == "ereh"){
         echo "<h1><font size=25 color = Gold><center>Vencedor:</center></font>
		       <font color = White><center><b>Eren Yaeger</b></center></font>;
	           <center><img src=ereh.png height=300 width=340></center>";
      }
	  else if($time1 == "livai"){
         echo "<h1><font size=25 color = Gold><center>Vencedor:</center></font>
		       <font color = White><center><b>Levi</b></center></font>
	           <center><img src= levizinho.png height=200 width=200></center>";
      }
	  else if($time1 == "Mikasa"){
		echo "<h1><font size=25 color = Gold><center>Vencedor:</center></font>
			  <font color = White><center><b>Mikasa</b></center></font>
			  <center><img src= mikasa.jpg height=300 width=320></center>";
	 }
	  else if($time1 == "Armin"){
        echo "<h1><font size=25 color = Gold><center>Vencedor:</center></font>
		      <font color = White><center><b></b></center></font>
	          <center><img src=armin.png height=300 width=290></center>";
      }
		
   }
   else if($p2 > $p1){
      if($time2 == "reiner"){
         echo "<h1><font color = Gold><center>Vencedor:</center></font>
		      <font color = White><center><b>Reiner</b></center></font>
	          <center> <img src=Reiner.jpg height=150 width=200></center>";
      }
      else if($time2 == "bert"){
          echo "<h1><font color = Gold><center>Vencedor:</center></font>
	            <font color = White><center><b></b></center></font>
	            <center><img src=bertinho.jpg height=300 width=340></center>";
      }
	  else if($time2 == "annie"){
		echo "<h1><font color = Gold><center>Vencedor:</center></font>
			  <font color = White><center><b></b></center></font>
			  <center><img src=annie.png height=400 width=400></center>";
	}
      else if($time2 == "porco"){
          echo "<h1><font color = Gold><center>Vencedor:</center></font>
	            <font color = White><center><b>Porco</b></center></font>
	            <center><img src=porco.jpg height=300 width=340></center>";
      }
   }
   else if($p1 == $p2){
      
	 
	  if($time1 == "ereh"){
	     echo "<table align = center>
		           <tr>
					     <center><h1><font color = Gold><b>Empate:</b></font></center>
				   </tr>
				   <tr>
				      <td>
					  <h1><font color = White><center><b>Eren Yaeger</b></center></font>
	                    <center><img src=ereh.png height=300 width=340></center>
					  </td>
					  <td>
					  <h1><font align=center><b>=</b></font>
					  </td>
					  <td>
					  <h1><font color = White><center><b>Reiner</b></center></font>
	                     <center><img src=reiner.jpg height=300 width=300></center>
					  </td>
				   </tr>
		       </table>";
	  }
	  else if($time1 == "armin"){
	     echo "<table align = center>
		           <tr>
					     <center><h1><font color = Gold><b>Empate:</b></font></center>
				   </tr>
				   <tr>
				      <td>
					   <font color = White><center><b>Armin</b></center></font>
	                   <center><img src=ereh.jpg height=300 width=340></center>
					  </td>
					  <td>
					     <font size = 25 align=center><b>=</b></font>
					  </td>
					  <td>
					     <font color = White><center><b>Porco</b></center></font>
	                     <center><img src=porco.jpg height=300 width=340></center>
					  </td>
				   </tr>
		       </table>";
	  }
	  if($time1 == "livai"){
		echo "<table align = center>
				  <tr>
						<center><font size = 13 color = Gold><b>Empate:</b></font></center>
				  </tr>
				  <tr>
					 <td>
					   <font color = White><center><b>Levi</b></center></font>
					   <center><img src=levi.jpg height=300 width=320></center>
					 </td>
					 <td>
						<font size = 25 align=center><b>=</b></font>
					 </td>
					 <td>
						<font color = White><center><b>Berthold</b></center></font>
						<center> <img src=bertinho.jpg height=300 width=320></center>
					 </td>
				  </tr>
			  </table>";
	 }
	  if($time1 == "mikasa"){
	     echo "<table align = center>
		           <tr>
					     <center><font size = 13 color = Gold><b>Empate:</b></font></center>
				   </tr>
				   <tr>
				      <td>
					    <font color = White><center><b>Mikasa</b></center></font>
	                    <center><img src=mikasa.jpg height=300 width=320></center>
					  </td>
					  <td>
					     <font size = 25 align=center><b>=</b></font>
					  </td>
					  <td>
					     <font color = White><center><b>Annie</b></center></font>
	                     <center> <img src=annie.png height=300 width=320></center>
					  </td>
				   </tr>
		       </table>";
	  }
   }
      
?>