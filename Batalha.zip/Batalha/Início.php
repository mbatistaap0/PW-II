﻿<!-- trocar os personagens, suas imagens e suas forças.
personalizar os empates
aumentar em 2 personagens, total de 8. 
inserir plano de fundo estilizado nos dois arquivos -->
<html>
   <head>
   <meta charset= "UTf-8">
   <body background = "fundoinicio.jpg">
  </head>
      <form method="POST" action="Batalha.php">
		   <table border="0" align="center">
		     <tr>
               <td>
			     <h1><font color = "White"><center>Eren</center></font>
			     <img src="eren.gif" height="300" width="300"><br>
				 <center><input type="radio" name="Time1" value="ereh"></center>
			   </td>
			   
			   <td>
			   <h1><font color = "White"><center>Levi</center></font>
			     <img src="levi.gif" height="300" width="370"><br>
				 <center><input type="radio" name="Time1" value="livai"></center>
			   </td>

               <td>
			   <h1><font color = "White"><center>Mikasa<br></center></font>
				 <img src="mikasa.gif" height="300" width="300"><br>
				 <center><input type="radio" name="Time1" value="Mikasa"></center>
			   </td>			
               <td>
			   <h1><font color = "White"><center>Armin</center></font>
				 <img src="arminn.gif" height="300" width="300"></br>
                 <center><input type="radio" name="Time1" value="Armin"></center>
			   </td>
              </h1>
			 </tr>
		  </table>
		  
		 <center><font size="13" color = "Red">VS</font></center>
		 <table border="0" align="center">
		 
			<tr>    
			  <td>
			  <h1><font color = "White"><center>Reiner</center></font>
			    <img src="reiner.gif" height="300" width="260">
			    <center><input type="radio" name="time2" value="reiner"><center>
			  </td>	
               
			  <td>
			  <h1><font color = "White"><center>Berthold</center></font>
			    <img src="bertinho.gif" height="300" width="310">
			    <center><input type="radio" name="time2" value="bert"><center>
			  </td>	

			   
              <td>
			  <h1><font color = "White"><center>Annie<br></center></font>
			    <img src="annie.gif" height="300" width="260">
			    <center><input type="radio" name="time2" value="Annie"><center>
			  </td>
		
			  
              <td>
			  <h1><font color = "White"><center>Porco</center></font>
		        <img src="porco.gif" height="300" width="320">
			    <center><input type="radio" name="time2" value="porco"><center>
			  </td>
			</tr>
			
         </table>		
         <br>
         <center><input type="submit" value="PLAY"></center>	 
	  </form>
	<style>
    img {
    	border: 7px solid black;
	  	padding: 2px;
	  	margin-right: 20px;
    }
	body {
     	font-family: "cloister_black";
    }
	custom-input {
      padding: 10px; 
      font-size: 16px; 
      border: 1px solid #ccc; 
      border-radius: 4px; 
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); 
  </style> 
   </body>
</html>

