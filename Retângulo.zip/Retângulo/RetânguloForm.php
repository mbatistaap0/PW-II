<!-- Estilizar plano de fundo e textos -->
<html>
<head>
	<style>
		body {
			background-image: url("matback.jpg");
			background-repeat: no-repeat;
			background-size: cover;
      font-family: Georgia;
      font-size: 18px;
      text-align: center;
      background-color: #ffcc8e;
		}
    input {
      background-color: #ffffff;
      border: 2px solid darkgray;
    }
        
	</style>
</head>
<body>
<fieldset style="margin: 480px; border-color: black; border-radius: 4px ; width: 210px; border: groove; border-width: 45px; border-style: ridge; background-color: lightgray">
<form action="Retângulo.php" method="get">
 <p>Comprimento:   <input type="text" name="C" /></p>
 <p>Altura:  <input type="text" name="A" /></p>
 <div class="container mt-5">
 <div class="row justify-content-center">
    <form>
      <button type="submit"  class="btn btn-warning btn-lg btn-block">Enviar</button>
    </form>
    </div>
</form>
</body>



