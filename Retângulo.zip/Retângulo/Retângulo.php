<!-- Estilizar imagem de fundo e textos
somente formatar -->
<html>
<head>
<title>Área do Retângulo</title>
</head>
	<style>
	    body {
			background-image: url("matback.jpg");
			background-repeat: no-repeat;
			background-size: cover;
			font-family: Georgia;
		    font-size: 18px;
		}

	</style>
<body>
<fieldset style="margin: 475px; border-color: black; border-radius: 4px ; width: 215px; border: outset; border-width: 40px; border-style: ridge; background-color: lightgray">
	<div class="quadro">
		<h2>Resultado</h2>
		<?php
		$Alt = $_GET["A"];
		$Comp = $_GET["C"];
		$resultado = ($Alt + $Comp) * 2;
		echo "Área do retângulo: $resultado";
		?>
	</div>
<footer>
  <p> @registro by Maria Clara.</p>
</footer>
</body>
</html>