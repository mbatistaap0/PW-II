<!-- Tabuada, entre com um número:
Formatar com css cor de fundo e o resultado com uma cor e tamanho
Faça comentário do código com // nas linhas do php-->

<!DOCTYPE html>
<html>
<body>
<head>
<fieldset style="margin: 150px; border-color: black; border-radius: 4px ; width: 40px; border: groove; border-width: 25px; border-style: groove; background-color: darkgray">
<h1 style= "margin: 5px"></h1>
<form method="post">
  <font color = black>
  <center>
  <label><br>DIGITE O NÚMERO DESEJADO: <input type="text" name="txtNumero1"/></label>
  </font>
</center>

<style>
*{margin:50px}

div{background-color: lightgray; 
	border: 7px solid black;
	padding:10px}

p{font-size:30px} 
	
.classe1{ 
  background:#ffd919;
  color:#d95766;
  background-image = url('fundotab.jpg')
  font-size:70px;
  font-weight:bold;
  text-align: left;
  opacity:20;
  box-shadow: 0px 10px 10px 10px #f03c1d;
  width:500px;
  text-shadow:15px -2px 20px #fff;
  }
 
  body{background-image = url(fundotab.jpg)
  background-size: 70px}

</style>
<body background = "fundotab.jpg">
<div align="center">
</head>
<p>Tabuada</p>

<center>
<?php
$num = filter_input(INPUT_POST, "txtNumero1");
  for($i = 0; $i <= 10; $i++){
  echo "{$num} * {$i} = ".($num * $i)."<br>"; }
?>
</center>
<body>
</html>