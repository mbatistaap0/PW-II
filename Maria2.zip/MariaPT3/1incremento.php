<!-- troque a cor dos resultados no echo para Vermelho, tamanho 40px e cor de fundo a seu gosto. -->
<html>
<head>
<style>
h1{font-size:30px; font-family: Georgia;
  background-color: gray;
  opacity: 0.7;
  text-align: center;
}
body{background-image:url("fundoincrement.jpg");
	background-size: 100%;
	background-repeat: ;}

p{font-size:40px; color:red;}

div{background-color:#b5ed69; 
	border: 5px solid yellow;
	padding:5px}

.classe1{ 
  background:#ffd919;
  color:#d95766;
  font-size:40px;
  font-weight:bold;
  text-align: center;
  opacity:1;
  box-shadow:2px 1px 10px 10px #f03c1d;
  width:400px;
  text-shadow:20px -2px 20px #fff;
}

</style>
</head>
<body>
</body>
</html>
<?php
$val = 'texto';
if (!is_numeric($val)) {
    echo "<h1>INCREMENTO</h1>";}
$a = 1;
echo "<p>$a</p>";
// imprime variável com css
echo "<br>"; 
echo $a + $a++; 
// imprime incremento
echo "<br>";

$i = 9;
echo "<p>$i</p>";
// imprime variável
echo "<br>";
$array[$i] = $i++; 
// imprime incremento modo array
echo $i;
?>