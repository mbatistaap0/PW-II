<!-- Fatorial:
Formate outros valores de css no resultado e plano de fundo
-->

<html>
<head>
<title>FATORIAL</title>
<style>
p{font-size:40px; color:white;}
</style>
<body background = "background2.jpg">
</head>
<body>
</body>
</html>
<?php
  $n1 = 4;
 
  if($n1 > 0){
    $valor = $n1; 
    for($i = ($valor - 1); $i > 0; $i--){
		//$i = 2, enquanto > 0, $i=1
      $valor = $valor * $i;
    }
  }else{
    $valor = 0;
  }
 
  echo "<p>$n1! = $valor</p>";
  

 ?>