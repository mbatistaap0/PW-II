
<!-- Outro Arquivo
	restaurante.php:
	receber as quantidades, criando variáveis.
	multiplicar as quantidades pelo valor do produto , colocando-as em variáveis.
	Somar o total gasto , colocando numa variável.
	Imprimir com uma frase: Ex. Total de gasto=x, usar echo.
	Estilizar.
-->
<html>
<head>
</head>
    <title>Área do triângulo</title>
	<style>
	    body {
			background-image: url("matback.jpg");
			background-repeat: no-repeat;
			background-size: cover;
		}
	</style>
<body>
<fieldset style="margin: 430px; border-color: black; border-radius: 4px ; width: 200px; border: outset; border-width: 40px; border-style: ouset; background-color: lightgray">
	<div class="quadro">
		<h1>Área</h1>
		<h3>
		<?php
		$refriQuantidade=$_GET["a"];
		$sucoQuantidade=$_GET["b"];

		$refri=3,00 * $refriQuantidade;
		$suco=5,50 * $sucoQuantidade;

		total = $refri + $suco +..........;
		echo "Área do triângulo: $resultado";
		?>
		</h3>
	</div>
<footer>
  <p> @ registro by Maria Clara.</p>
</footer>
</body>
</html>

