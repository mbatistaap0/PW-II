<form action="Restaurante.php" method="get">
<h1> Quantidades desejadas</h1>
<p>Maçã Pacote R$8,00 <input type="text" name="a" /></p>
<p>Suco Natural R$5,50: <input type="text" name="b" /></p>
<p>Pacote de aveia R$5,50: <input type="text" name="c" /></p>
<p>Cheese Burger R$4,00: <input type="text" name="d" /></p>
<p>Cheese Egg R$4,90: <input type="text" name="e" /></p>
<p>Cheese Calabresa R$8,00: <input type="text" name="f" /></p>
<p>Cheese Bacon R$9,00 : <input type="text" name="g" /></p>
<p>Cheese Tudo R$12,00: <input type="text" name="h" /></p>
 
<p><input type="submit" /></p>
</form>

<!-- Outro arquivo
	restaurante.php:
	receber as quantidades, criando variáveis.
	multiplicar as quantidades pelo valor do produto , colocando-as em variáveis.
	Somar o total gasto , colocando numa variável.
	Imprimir com uma frase: Ex. Total de gasto=x, usar echo.
	Estilizar.


$refriQuantidade=$_GET["a"];
$sucoQuantidade=$_GET["b"];

$refri=3,00 * $refriQuantidade;
$suco=5,50 * $sucoQuantidade;

total = $refri + $suco +..........;
usar fonts.google.com
	-->