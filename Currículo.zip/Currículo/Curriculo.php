﻿<!-- criar novos dados para 4 curriculos
inserir mais dois <td> com dados de mais um curriculo (4) na tabela
inserir plano de fundo -->
<?php
   if(isset($_POST["Curriculo1"])){
      echo "<center><h1>CURRÍCULO</h1></center>
	        <table align=center>
			   <tr>
			     <td>
				   <img src=rosa.jpg width = 200 height = 200>
				   <style>
				 h1 {
					font-family: Impact;
					text-shadow: 8px 4px -1 black;
					letter-spacing: 2px;
				 }
				 img {
					border-radius: 7px;
					margin-right: 20px;
					border: 5px solid black;
				 }
				 body {
				   background-image: url('background3.jpg');
				   background-size: cover;
				 }
				 body {
					font-family: Impact;
					color: #ffffff;
					line-height: 2.5;
					text-shadow: 2px 1.5px 0 black;
					letter-spacing: 0.5px;
					font-weight: bold;
				}
				</style>
				 </td>
				 <td>
				   Nome: Rosa Diaz<br>
				   Idade: 32 anos<br>
				   Cargo: Detetive Particular<br>
				   Altura: 1,66 m<br>
				   Descrição: Trabalhou como detetive na 99° Delegacia de Polícia em Nova Iorque<br> Atualmente segue a carreira de Detetive Particular.
				 </td>
				 </tr>
				 </table>";
   }
   if(isset($_POST["Curriculo2"])){
      echo "<center><h1>CURRÍCULO<h1></center>
	        <table align=center>
			   <tr>
			     <td>
				   <img src=peralta.jpg width = 200 height = 200>
				   <style>
				 h1 {
					font-family: Impact;
					text-shadow: 5px 1px -1 black;
					letter-spacing: 2px;
				 }
				 img {
					border-radius: 7px;
					margin-right: 20px;
					border: 5px solid black;
				 }
				 body {
				   background-image: url('background3.jpg');
				   background-size: cover;
				 }
				 body {
					font-family: Impact;
					color: #ffffff;
					line-height: 2.5;
					text-shadow: 2px 1.5px 0 black;
					letter-spacing: 0.5px;
					font-weight: bold;
				}
				</style>
				 </td>
				 <td>
				   Nome: Jacob Peralta<br>
				   Idade: 35 anos<br>
				   Cargo: Detetive<br>
				   Altura: 1,70 m<br>
				   Descrição: Trabalha como detetive na 99° Delegacia de Polícia em Nova Iorque.
				 </td>
				 </tr>
				 </table>";
   }
   if(isset($_POST["Curriculo3"])){
	echo "<center><h1>CURRÍCULO<h1></center>
		  <table align=center>
			 <tr>
			   <td>
				 <img src=gina.jfif width = 200 height = 200>
				 <style>
				 h1 {
					font-family: Impact;
					text-shadow: 5px 1px -1 black;
					letter-spacing: 2px;
				 }
				 img {
					border-radius: 7px;
					margin-right: 20px;
					border: 5px solid black;
				 }
				 body {
				   background-image: url('background3.jpg');
				   background-size: cover;
				 }
				 body {
					font-family: Impact;
					color: #ffffff;
					line-height: 2.5;
					text-shadow: 2px 1.5px 0 black;
					letter-spacing: 0.5px;
					font-weight: bold;
				}
			   </style>	 
			   </td>
			   <td>
				 Nome: Gina Linetti<br>
				 Idade: 35 anos<br>
				 Cargo: Digital Influencer<br>
				 Altura: 1,64<br>
				 Descrição: Trabalhou como assistente e secretária do Capitão Raymond Holt na <br>99° Delegacia de Polícia.
				 Pediu demissão para se tornar uma celebridade,<br> atualmente possui milhões de seguidores nas redes sociais e é <br>reconhecida mundialmente.
			   </td>
			   </tr>
			   </table>";
 }
 if(isset($_POST["Curriculo4"])){
	echo "<center><h1>CURRÍCULO<h1></center>
		  <table align=center>
			 <tr>
			   <td>
				 <img src=holt.jfif width = 200 height = 200>
				 <style>
				 h1 {
					font-family: Impact;
					text-shadow: 5px 1px -1 black;
					letter-spacing: 2px;
				 }
				 img {
					border-radius: 7px;
					margin-right: 20px;
					border: 5px solid black;
				 }
				 body {
				   background-image: url('background3.jpg');
				   background-repeat: no-repeat;
				   background-size: cover;
				 }
				 body {
					font-family: Impact;
					color: #ffffff;
					line-height: 2.5;
					text-shadow: 2px 1.5px 0 black;
					letter-spacing: 0.5px;
					font-weight: bold;
				}
				</style>
			   </td>
			   <td>
				 Nome: Raymond Holt<br>
				 Idade: 63 anos<br>
				 Cargo: Vice-Comissário<br>
				 Altura: 1,72 m<br>
				 Descrição: Atuou como Capitão de Polícia na 99° Delegacia de Polícia. <br> Atualmente, conhecido como Vice-Comissário da Polícia de Brooklyn - NY. <br> 

			   </td>
			   </tr>
			   </table>";
 }

?>