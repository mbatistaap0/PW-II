<html>
<body>

<?php
$nome = "Maria Clara";
$sobrenome = "Batista Aparecido":
$nascimento = "10/11/2006";

Echo "Nome:";
echo "$Nome <br>";
Echo "Sobrenome:";
echo "$sobrenome <br>";
Echo "Nascimento:";
echo "$nascimento <br>";
?>

</body>
</html>