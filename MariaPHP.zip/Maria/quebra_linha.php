<!-- quebras de linha -->
<html>
<head>
<style>
h1{font-size:15px; font-family: Georgia;
    text-align: left;
    top: 50px;
    color: white;
    }
body {background-image:url('fundoquebra.jpg');
    font-size: 35px;
    margin-left: 100px;
}


</style>
</head>
<body>

</body>
</html>
<?php

// modo 1 usando variável
$num = "\n<h1> 20";
echo nL2br($num);

//modo 2 direto
echo nL2br("\n 23");

$texto = "\n\n\n\n Olá \n\n\n  \n Me chamo Maria Clara \n Tenho 16 anos"; 
echo nL2br($texto);

$texto2 = "\n\n\n\n\n\n Amo gatinhos \n Gosto de música. \n E adoro o studio Ghibli";
echo nL2br($texto2);

echo nL2br("\n\n\n\n\n Att.\n Maria.</h1>");
?>



