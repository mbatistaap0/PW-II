<!-- somente executar -->
<html>
    <head>
        <body>
	        <body background = "fundovalor.jpg";>
	        <font color = white;>
         </font>
	    </body>
    </head>
</html>

<?php
// alterando valor da variável
	$nome = 'Nome: ';
	echo $nome;
	$nome1 = 'Maria Clara';
	echo $nome1;
	echo '<br>';
	$Nome2 = 'Idade: ';
	echo $Nome2;
	$Nome3 = '16';
	echo $Nome3;
	echo '<br>';
	$Info= 'Aluna da ETEC Ilza Nascimento Pintus';
	echo $Info;
	
	echo '<br>';

	echo '<br>';
?>

<?php
    $teste = "Livro Favorito: ";
	echo $teste;
    $Livro = 'Os dois morrem no final' ;
	echo $Livro;
	echo '<br>'; 
    $Filme = 'Filme: ' ;
	echo $Filme;
	$Nome_Filme = 'Interestelar';
	echo $Nome_Filme;
?>



