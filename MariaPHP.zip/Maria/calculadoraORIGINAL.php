<?php
// Programa permite ao usuário escolher uma operação (soma, subtração, multiplicação ou divisão). 
// duas caixas de texto para receber 2 números. 
// trocar o nome das variáveis, o nome que recebe os valores (caixas), a operação e a variável do resultado
// Centralizar, colocar cores, deixá-lo atrativo.
 
$a = filter_input(INPUT_POST, "txtNumero1");
$b = filter_input(INPUT_POST, "txtNumero2");
$c= filter_input(INPUT_POST, "slOperacao");
$resul = "";

if($a && $b){
  switch($c){
    case "+":
      $resul = ($a + $b);
    break;
    case "-":
      $resul = ($a - $b);
    break;
    case "*":
      $resul = ($a * $b);
    break;
    case "/":
      $resul = ($a / $b);
    break;
  }
}
 
?>
 
 <!DOCTYPE html>
 <html>
   <head>
 
     <meta charset="utf-8">
     <title>Operações</title>
     <style>
      input, select{padding:10px; margin: 5px;}
      @import url('https://fonts.cdnfonts.com/css/first-school');
     </style>
     <body background = "Background.jpg">
   </head>
   <body style= "background.jpg">
   <center>
   <fieldset style="margin: 350px; border-color: black; border-radius: 8px ; width: 90px; border: groove; border-width: 45px; border-style: groove; background-color: lightgray">
     <h1 style= "margin: 10px"><?=$resul;?></h1>
     <form method="post">
      <font color = black>
        <font-family: First School sans-serif;>
       <label>Número 1: <input type="text" name="txtNumero1"/></label><br>
       <label>Número 2: <input type="text" name="txtNumero2"/></label><br>
       <label>Operação:
         <select name="slOperacao">
           <option value="+">Adição</option>
           <option value="-">Subtração</option>
           <option value="*">Multiplicação</option>
           <option value="/">Divisão</option>
         </select>
       </label><br>
       </font>
       <input type="submit" name="btnCalcular" value="Calcular">
     </form>
    </center>
   </body>
 </html>
