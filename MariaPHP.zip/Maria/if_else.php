<!-- Este programa exibe positivo, negativo ou nulo de acordo com a entrada pelo usuário.
Trocar as entradas e formatar H1 e fundo com css. -->

<html>
<head>
<Style>
h1{font-size:30px; font-family: Georgia;
	background-color: white;
  opacity: 0.7;
  text-align: center;
}
	
body{background-image:url("ifundo.jpg");
	background-size: 100%;
	background-repeat: ;}
</style>
</head>
<body>
  <center>
</body>
</html>
<?php
$val = "texto";
$resultado="";

if (!is_numeric($val)) {
echo "<h1>Você digitou LETRAS</h1>";}
else  {

if($val > 0){
  $resultado = "Valor Positivo";
}elseif($val < 0){
  $resultado = "Valor Negativo";
}else{
  $resultado = "Igual a Zero";
}
}

?>
 
<h1><?=$resultado;?></h1>