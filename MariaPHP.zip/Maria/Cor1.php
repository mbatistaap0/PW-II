<!DOCTYPE html>
<html>
<body>

<?php
$color = "vermelha";
$color2 = "roxo";
$color3 = "azul";
echo "Minha casa é <font color= red> $color </font><br>";
echo "Minha bicicleta é <font color= purple> $color2 </font><br>";
echo "Meu skate é <font color= blue> $color3 </font>";
?>

</body>
</html>