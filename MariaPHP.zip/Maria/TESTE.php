<html>
<head>
</head>
<body>
    <div>
        <?php
           $nome= "Maria";
           $idade = 18;
           echo "$nome tem $idade anos!";
        ?>
</div>
</body>
</html>