<html>
    <head>
        <title>CAIXA</title>
        <meta charset = "utf-8">
        <style>
@import url('https://fonts.googleapis.com/css2?family=Archivo+Black&family=Lora:ital@0;1&family=PT+Serif&family=Rubik+Puddles&family=Tilt+Prism&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Rubik+Puddles&display=swap');

body{
    background-image:url(fundo3.jpg);
	background-size: 100% 110%;
	background-repeat: no-repeat;}
p{
	font-family: 'Lora', serif;
    position: absolute; 
    top: 181px; 
    left: 590px;
	color: yellow;
	font-size:25px;
}
h1{
	font-family:'Rubik Puddles';
	font-size: 50px;
	color: black;
	text-align:center;
}

</style>
        </head>
<body>
<h1>TOTAL</h1>
</body>
<p> 
<?php
$refriQuantidade=$_GET["a"];
$sucoQuantidade=$_GET["b"];
$CheeseSaladaQuantidade = $_GET["c"];
$CheeseBurguerQuantidade = $_GET["d"];
$CheeseEggQuantidade = $_GET["e"];
$CheeseCalabresaQuantidade = $_GET["f"];
$CheeseBaconQuantidade = $_GET["g"];
$CheeseTudoQuantidade = $_GET["h"];

$refri=3.00 * $refriQuantidade;
$suco=5.50 * $sucoQuantidade;
$CheeseSalada = 5.50 * $CheeseSaladaQuantidade;
$CheeseBurguer = 4.00 * $CheeseBurguerQuantidade;
$CheeseEgg = 4.90 * $CheeseEggQuantidade;
$CheeseCalabresa = 8.00 * $CheeseCalabresaQuantidade;
$CheeseBacon = 9.00 * $CheeseBaconQuantidade;
$CheeseTudo = 12.00 *$CheeseTudoQuantidade;
$total = $refri + $suco + $CheeseSalada+ $CheeseBurguer+$CheeseEgg+$CheeseCalabresa+$CheeseBacon+$CheeseTudo ;
echo "R$$total";
?>
</p>
</html>
