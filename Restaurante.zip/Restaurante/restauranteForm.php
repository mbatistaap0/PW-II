<form action="restaurante.php" method="get">
<html>
    <head>
		<title>PEDIDO</title>
    <meta charset = "utf-8">
   <style>
@import url('https://fonts.googleapis.com/css2?family=Rubik+Puddles&display=swap');


body{
    background-image:url(fundo1.jpg);
	background-size: 100% 100%;
	background-repeat: no-repeat;}
p{
	font-family: 'Rubik Puddles';
	color: white;
	font-size:25px;
	text-align:center;
}
h1{
	font-family:'Rubik Puddles';
	font-size: 50px;
	color: white;
	text-align:center;
}
input{
	font-size:15px;
	width:55px;
}
input[type=submit] {
            background-color: #ffffff;
			font-family: 'Lora';
			background-color: #656149;
            color: black;
            border: groove;
            border-radius: 5px;
			width:300px;
            padding: 10px 20px;
            cursor: pointer;
            } 
</style>
</head>
<body>
		<br><br><br><br>
<h1> QUANTIDADES CONSUMIDAS</h1>
<center>
<fieldset style="margin: 100px; border-color: darkgray; border-radius: 4px ; width: 600px; height: 440px; border: black; border-width: 45px; border-style: groove; background-color: black">

<p>Refrigerante . . . . .    R$3,00: <input type="text" name="a" /></p>
<p>Suco . . . . .    R$5,50: <input type="text" name="b" /></p>
<p>Cheese Salada . . . . .    R$5,50: <input type="text" name="c" /></p>
<p>Cheese Burger . . . . .   R$4,00: <input type="text" name="d" /></p>
<p>Cheese Egg . . . . .    R$4,90: <input type="text" name="e" /></p>
<p>Cheese Calabresa . . . . .    R$8,00: <input type="text" name="f" /></p>
<p>Cheese Bacon . . . . .    R$9,00 : <input type="text" name="g" /></p>
<p>Cheese Tudo . . . . . R$12,00: <input type="text" name="h" /></p>
<br><br>
<p><input type="submit" value="CONFIMAR PEDIDO"/></p>
</center>
<br><br><br><br>
</form>
</body>
</html>

<!-- Outro arquivo
	restaurante.php:
	receber as quantidades, criando variáveis.
	multiplicar as quantidades pelo valor do produto , colocando-as em variáveis.
	Somar o total gasto , colocando numa variável.
	Imprimir com uma frase: Ex. Total de gasto=x, usar echo.
	Estilizar.


$refriQuantidade=$_GET["a"];
$sucoQuantidade=$_GET["b"];

$refri=3,00 * $refriQuantidade;
$suco=5,50 * $sucoQuantidade;

total = $refri + $suco +..........;
usar fonts.google.com
	-->